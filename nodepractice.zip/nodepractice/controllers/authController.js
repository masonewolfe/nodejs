const User = require('../model/User');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const handleLogin = async(req,res) => {
    const {user, pwd} = req.body;
    if(!user || !pwd) return res.status(400).json({"message":"username and/or password are required"});
    const foundUser = await User.findOne({user:user}).exec();
    if(!foundUser){return res.status(401).json({"message":"username not found"})};

    //try to match password
    const match = await bcrypt.compare(pwd, foundUser.pwd);
    if(match){
        //creating login tokens
        const accessToken = jwt.sign(
            {"userInfo":{"user":foundUser.user, "userCode":foundUser.userCode}},
            process.env.ACCESS_TOKEN_SECRET,
            {expiresIn:'900s'}
        );
        const refreshToken = jwt.sign(
            {"user":foundUser.user},
            process.env.REFRESH_TOKEN_SECRET,
            {expiresIn:'1d'}
        );

        //saving refresh token in a database for cross referencing
        foundUser.refreshToken = refreshToken;
        const result = await foundUser.save();
        console.log(result);

        //sending refresh token in a cookie (http only)
        res.cookie("jwt", refreshToken, {httpOnly:true, sameSite:'None', maxAge:24*60*60*1000}); // secure=true,
        //sending access token
        res.status(200).json({accessToken});
    }else{
        res.status(401).json({"message" :"wrong password"});
    }
}

module.exports = {handleLogin};