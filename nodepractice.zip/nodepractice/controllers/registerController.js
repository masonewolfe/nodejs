const User = require('../model/User');
const bcrypt = require('bcrypt');

const handleNewUser = async(req,res) => {
    const {user, pwd} = req.body;
    if(!user || !pwd) return res.status(400).json({"message":"username and/or password are required"});
    //check for duplicate usernames
    const duplicate = await User.findOne({user:user}).exec();

    if(duplicate) return res.status(409).json({"message":"username taken"});

    try{
        //encrypt
        const hashPwd = await bcrypt.hash(pwd, 10);
        //create and store new user
        const result = await User.create({"user":user,"pwd":hashPwd});
        
        console.log(result);
        res.status(201).json({"message":"success!"});

    }catch(err){
        res.status(500).json({"message":err.message});
    }
}

module.exports = {handleNewUser};