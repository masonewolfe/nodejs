const ROLES_LIST = {
    "Admin":999,
    "User" :1
}

module.exports = ROLES_LIST