const {format} = require('date-fns')
const path = require('path')
const {v4 : uuid} = require('uuid')
const fs = require('fs')
const fsPromises = require('fs').promises

const logEvents = async(message, logName) =>{
    const dateTime = `${format(new Date(), 'MM/dd/yyyy\tHH:mm:ss')}`;
    const logItem = `\n${dateTime}\t${uuid()}\t${message}`;
    try{
        await fsPromises.appendFile(path.join(__dirname, '..', 'logs', logName), logItem);
    }catch(err){
        console.log(err);
    }
}

const logger = (req,res,next)=>{
    logEvents(`${req.method} ${req.headers.origin} ${req.url}`, 'reqLog.txt')
    next();
}
module.exports = {logger, logEvents};