const verifyRoles = (...allowedRoles) =>{
    return (req,res,next) =>{
        if(!req?.userCode) return res.sendStatus(401);
        const roleArray = [...allowedRoles];
        console.log(roleArray);
        console.log(req.userCode);

        const result = roleArray.includes(req.userCode);
        if(!result) return res.sendStatus(401);
        next();
    }
}

module.exports = verifyRoles