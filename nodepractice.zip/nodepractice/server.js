require('dotenv').config();

const mongoose=require('mongoose');
const conectDB = require('./config/dbConn');
const express = require('express');
const app = express();
const path = require('path');
const cors = require('cors');
const corsOptions = require('./config/corsOptions').corsOptions;
const credentials = require('./middleware/credentials')
const errorHandler = require('./middleware/errorHandler');
const {logger} = require('./middleware/logevents');
const verifyJWT = require('./middleware/verifyJWT');
const cookieParser = require('cookie-parser');
const port = process.env.PORT || 3500;

//connect to mongodb
conectDB();

//custom middleware logger
app.use(logger);
//handle option credentials check before cors
app.use(credentials);
//cross origin resource sharing
app.use(cors(corsOptions));
//built in middleware for handling form data
app.use(express.urlencoded({extended:false}));
//built in middleware for json
app.use(express.json());
//middleware for cookies
app.use(cookieParser());


// routes
app.use('/', require('./routes/root'));
app.use('/register', require('./routes/api/register'));
app.use('/auth', require('./routes/api/auth'));
app.use('/refresh', require('./routes/api/refresh'));
app.use('/logout', require('./routes/api/logout'));

app.use(verifyJWT);
app.use('/employees', require('./routes/api/employees'));
// serve a 404 otherwise
app.all('*', (req,res) => {
    res.status(404);
    if(req.accepts('html')){
        res.sendFile(path.join(__dirname, 'views', '404.html'));
    }
    else if(res.accepts('json')){
        res.json({error: "404 NOT FOUND"});
    }
    else {
        res.type('txt').send("404 NOT FOUND");
    }
});
//log errors in console
app.use(errorHandler);

mongoose.connection.once('open', () =>{
    console.log('connected to mongodb');
    app.listen(port, ()=>console.log(`Server running on port : ${port}`));
})
